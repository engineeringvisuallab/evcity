/**
 * Central configuration. Every magic number lives here.
 * Units: metres, seconds.
 */
export const Config = {
  world: {
    /** World is exactly 10 km x 10 km (the playable area). */
    size: 10_000,
    /** One chunk = 500 m x 500 m -> exactly 20 x 20 chunks. */
    chunkSize: 500,
    /** Extra chunk rings rendered outside the playable area so the edge is never a visible void. */
    chunkMargin: 2,
    /** Master seed. Same seed -> same world, nothing stored on disk. */
    seed: 20260101,
  },

  terrain: {
    /**
     * Brown SOIL (with pebbles) showing through the grass on flat land: soil share = smoothstep(soilFrom, soilTo, noise). The noise is ~0.5 on average,
     * so 0.50..0.64 was about half of the land; 0.30..0.44 makes soil the main ground (~80 %), with green patches in between.
     * Lower both = more soil, higher = more green.
     */
    soilFrom: 0.3, // soil is the main ground again: grass only in patches (was 0.8 / 0.95 = grass everywhere, too heavy for the PC)
    soilTo: 0.44,
    /**
     * GREEN CITY GROUND: inside the planned city areas (CityPlan: distance to the site hub < maxRadius) the ground is lawn green, not brown soil.
     * The chunk worker builds a per-vertex greenness mask (`aCity`): 1 inside the city, falling to 0 over `fadeOut` metres outside it.
     * The terrain shader multiplies the soil share (and the soil on slopes) by (1 - greenness * `amount`) and tints the grass colour `lawnTint`
     * towards a fresh lawn green. amount 0 = old behaviour (brown soil everywhere).
     */
    cityGreen: { amount: 0.55, fadeOut: 120, lawnTint: 0.35, slopeSoilKeep: 0.05 },
    seaLevel: 0,
    /** Highest possible terrain point (rim mountains). Used by shader/snow line and sanity checks. */
    maxHeight: 650,
    /** Skirt depth (m) per LOD: hangs below chunk borders to hide cracks between different LODs. */
    skirtDepth: [8, 16, 32, 64] as number[],
    /** Main island in the southern sea (about 2 km2). Centre in world metres (x east, z south). */
    island: {
      x: -1400,
      z: 4050,
      /** Mean radius (m) of the shoreline; the real outline is bent by noise. pi*830^2 = 2.16 km2 */
      radius: 830,
      /** How strongly noise bends the outline (0 = perfect circle). */
      wobble: 0.26,
      /** Highest hill at the middle of the island (m above sea). */
      peak: 46,
      /** Height (m) of the sand beach shelf right at the shoreline. */
      beach: 1.4,
    },
    river: {
      /** Coarse grid (m) used once at start to route rivers downhill (priority-flood). */
      gridStep: 80,
      /** Drainage area (in grid cells) a cell needs to become a river. Lower = more rivers. */
      accThreshold: 450,
      /** A river never cuts a gorge deeper than this (m); deeper -> river ends in a pond. */
      maxCut: 22,
      maxLakes: 3,
    },
  },

  roads: {
    /**
     * The road network grows tier by tier (one tier per stage), never all at once:
     *   1 = main roads (freeways)  2 = + primary (arterial)  3 = + secondary (collector)  4 = + tertiary (local / city streets).
     * Stage 6A = 1, 6B = 2, 6C = 3.
     */
    activeTier: 0 as 0 | 1 | 2 | 3 | 4, // 0 = NO roads at all (roads removed; set 1-4 again when the new road design is ready)
    /** ROADS STEP 5.1: the new 8-lane ring road (M8, roads/ring/RingRoad.ts). Works with activeTier 0. `step` = distance between centreline points (m). enabled = false: no ring. */
    ring: { enabled: true as boolean, step: 8 },
    /** ROAD SIGN BOARDS (HANDOFF_ROAD_DESIGN.md section 23): overhead sign gantries (src/signs/RoadSignLayer.ts, data src/signs/RoadSignData.ts made by scripts/gen-road-signs.ts). enabled = false: none. */
    signs: { enabled: true as boolean },
    /** ROADS STEP 9.2: interchange J1 (stack, 4 level, src/interchange/m8). OFF until the outward M8 roads fix its place (6.3); x, z = world position of the crossing, y = height of road A, yaw = turn of road A. Terrain is not carved under it yet. */
    interchangeJ1: { enabled: false as boolean, x: 0, z: 0, y: 0, yaw: 0 },
    /** STEP J1-e1: the GROUND-LEVEL J1 (src/roads/junction): x, z = centre, yawDeg = turn of the N axis, y, a, b = pad plane (J1-g3 fit over the open star, docs/j1g3_pad.json; old J1-c1 fit is docs/j1c1.json), rCore = half size of the flat square (= J1_SA 100 m), emb = skirt (m, 30: arm fill up to 5.2 m needs a skirt of at least 24 m for slope 1:3). enabled = false: no J1, no terrain change. */
    junctionJ1: { enabled: true as boolean, x: -87, z: -277, yawDeg: 37.5, y: 18.213952768488063, a: -0.0007693744942258208, b: 0.003387472903877177, rCore: 100, emb: 30 },
    /** STEP J1-e2: the four M8 arms of J1 (src/roads/junction/J1ArmData.ts, made by tools/j1-arm-data.py) from s = 315 m to the T on the ring, as game roads J1-N / J1-E / J1-S / J1-W with their structures. false = no arm roads. */
    junctionJ1Arms: { enabled: true as boolean },
    /**
     * AUTO CONNECT AT GRADE, A-5 (HANDOFF_ROAD_DESIGN.md 24.12): pad mesh (asphalt, kerbs, island, stop line, zebra) + terrain carve for the junctions listed in `ids`
     * (src/roads/JunctionAuto*.ts). OFF = the game is exactly as before (no pad, no carve, no mesh). ON: only the listed ids, and only those whose checks all PASS are built.
     */
    autoJunction: { enabled: true as boolean, /** A-5c: with the flag ON, cut the old road ribbon inside the pads (segments with both points inside a pad outline get no ribbon). false = keep the ribbon under the pad (A-5b look). */ trimRibbon: true as boolean, /** A-6 step 2: the AI traffic / route planner treats the auto T pads as junctions (cars turn there; pad numbers = net.pads.length + auto pad index). Roundabouts are NOT included yet (A-6 step 3). Only works when enabled is true. false = cars ignore the auto pads as before. */ traffic: true as boolean, ids: ['JN163', 'JN033', 'JN028', 'JN037', 'JN043', 'JN056', 'JN059', 'JN060', 'JN064', 'JN073', 'JN076', 'JN083', 'JN124', 'JN147', 'JN165'] as string[] },
    /** RT-E ramp bridges M3 / M4 + arm viaduct widening (RE-9). ON (RE-9): set false to hide it. */
    junctionRte: { enabled: true as boolean },
    /** J7-C: the 300 ft junction (Purbachal style) solid preview mesh (J300Layer). Default OFF. Look without editing: open the game with ?j300=1. Junction centre world (-1659.9, -2410.4), deck 35.3 m. */
    junctionJ300: { enabled: ((): boolean => { try { return !(typeof location !== 'undefined' && new URLSearchParams(location.search).get('j300') === '0'); } catch { return true; } })() as boolean }, // 2026-11-25 (user): ON by default on the main link; add ?j300=0 to see the old roads (kill switch)
    /** RE-9 ground-level slip lanes RTE-A2S / RTE-S2A as one-way ramp roads (outside the arm viaduct window). */
    junctionRteLanes: { enabled: true as boolean },
    /** RE-9 (user 2026-11-22: 'bridge remove, ground e road'): the J1-E arm viaduct at stem d 160..271 (2 .. 5 m above a shallow dip) becomes a normal road on an embankment; the road profile is NOT changed. false = old viaduct. */
    junctionRteArmGround: { enabled: true as boolean },
    /** STEP 5 (user 2026-11-22): the viaduct wedge / wing strips beside the J1-E arm (RteMesh, old design with long added stem lanes that are not built any more). false (default) = not drawn, only the ramp bridges M3 / M4. true = old look. */
    junctionRteWedges: { enabled: false as boolean },
    /** RT-E guardrail (user 2026-11-23: 'connection road gula er 2 pase railing'): W-beam rail on both sides of the ground connection roads (slips RTE-A2S / S2A, tails RTE-TAIL-*). postStep m between posts, height m, slipEndGap m free at each slip end, mergeMargin m free before the AUTO MERGE zone of a tail. enabled false = no rail. */
    junctionRteRails: { enabled: true as boolean, postStep: 4, height: 0.75, slipEndGap: 12, mergeMargin: 6 },
    /** RT-E AI traffic (user 2026-11-23: 'traffic AI set koro'): cars use the four movements of the interchange (RteLink): exitChance = share of ring cars that leave by M3 (ring B) / A2S (ring A), m4Chance = share of arm cars (towards the ring) that take the flyover M4; the others take the slip S2A. enabled false = old T stand-in. */
    junctionRteTraffic: { enabled: true as boolean, exitChance: 0.3, m4Chance: 0.5, flyoverMs: 13, slipMs: 10.5 },
    /** HK-11b: AI through the Hatikamrul interchange (src/traffic/HkLink.ts). Needs hatikamrul.enabled. Every arm / link car leaves at the C-D tip: weights = share of the 3 movements (sum 1); ring cars take an exit with exitChance. */
    junctionJ300Traffic: { enabled: true as boolean, exitChance: 0.12, weights: { 'R6>R4': 0.5, 'R6>Eo': 0.25, 'R6>Wo': 0.25, 'R4>R6': 0.5, 'R4>Eo': 0.25, 'R4>Wo': 0.25, 'Ei>R6': 0.5, 'Ei>R4': 0.5, 'Wi>R6': 0.5, 'Wi>R4': 0.5 } as Record<string, number> }, // J10: AI paths through the 300 ft junction (J300Link); only with the J300 switch ON
    hkTraffic: { enabled: true as boolean, exitChance: 0.15, rampMs: 12, weights: { A2E: 0.25, A2W: 0.25, A2L: 0.5, L2W: 0.25, L2E: 0.25, L2A: 0.5 } as Record<string, number> },
    /** AI END LINKS (user 2026-11-23: 'sob junction diye car'): a road END that lies on / beside another road (T or continuation, no pad) is a junction for the AI: cars at that end turn onto the other road (both ways), cars on the other road turn into it with pTurnIn (pTurnInHighway on a big freeway). maxGap m = how far the end may be from the other road, maxAngleDeg = the other road must lie ahead of the end within this angle, levelDiff m = max level difference. enabled false = old behaviour (cars stop at such an end). */
    aiEndLinks: { enabled: true as boolean, maxGap: 25, maxAngleDeg: 70, levelDiff: 3, pTurnIn: 0.15, pTurnInHighway: 0.05 },
    /** AI CROSS LINKS (H3, user 2026-11-23): two roads that cross at the same level in the middle of both (no pad, no end link within 30 m): a car coming to the crossing sometimes turns onto the other road (either way). pTurn per crossing, pTurnHighway on a big freeway, levelDiff m = max level difference at the crossing. Give-way is NOT part of this (H3b). enabled false = cars only drive straight over such a crossing. */
    aiCrossLinks: { enabled: true as boolean, pTurn: 0.12, pTurnHighway: 0.04, levelDiff: 2, endMargin: 30 },
    /** H3b GIVE-WAY (2026-11-23, values ASSUMED): at a crossing / T of the H2 + H3 links the car of the lower road class (highway > arterial > collector > local; the ending road of a T always) stops at a line `lineGap` m before the kerb of the other road
     *  while a vehicle is in the crossing or reaches it sooner than the car needs to clear it. Same class: the car that gets there first goes, a tie gives way to the car from the right. markAhead = m before the crossing where the mark is put on the route, decel = braking (m/s2) to the line. */
    aiGiveWay: { enabled: true as boolean, markAhead: 48, lineGap: 2.0, decel: 2.8 },
    /** H4 TURN ROUND (2026-11-23, values ASSUMED): an AI car that cannot go on turns round on its own road with a K-turn (forward with full lock, reverse, forward ...), see TurnRound.ts / AIDriver.turnStep.
     *  (a) a free dead end: after waitEnd s at the end of the route (instead of being removed); (b) a vehicle has stood in front of it for waitBlocked s (not at a red light, a give-way line, a bus stop or a station).
     *  Only on an undivided ordinary road whose width is at least widthK x car length + 1 m (else: removed at a dead end, waits in a jam as before). maxPhases = forward / reverse runs, maxSeconds = the whole turn. */
    aiTurnRound: { enabled: true as boolean, waitBlocked: 30, waitEnd: 1.0, widthK: 1.7, maxPhases: 9, maxSeconds: 70 },
    /** AUTO MERGE (user 2026-11-22): an open ramp end that arrives beside another road, roughly parallel (gap <= maxGap m, angle <= maxAngleDeg), narrows smoothly over `length` m to a point on that road's paved edge. See RoadNetwork.autoMergeEnds. LEVEL CLEARANCE (RoadNetwork.levelClearance): the ramp keeps fillSlope (ramp above the other road) / cutSlope (below) metres of room per metre of level difference above levelFree m, the plan moves outward with at most lateralGrade m per m. */
    autoMerge: { enabled: true as boolean, length: 30, maxGap: 1.2, maxAngleDeg: 25, fillSlope: 3, cutSlope: 2, levelFree: 0.3, lateralGrade: 0.3 },
    /** STEP 17.1g-a: the island link M6-1 (6-lane, src/roads/island/IslandLinkData.ts, made by tools/island-link-data.py, deck option A of 17.1d) from the ring S node to the island centre, as game road 'M6-1' with its structure range. enabled = false: no island link.
     *  bridgeDeck = true (17.1g-b): the strait structure (mainland viaduct + bridge + island viaduct, s 489-873) has its plain girder mesh (RingBridgeGeometry.straitGirder, listed last in ringStructures()) and the ribbon is drawn on it. false = deck mesh off and the ribbon held back on the inner part (the old 17.1g-a state, only for checks). */
    islandLink: { enabled: true as boolean, bridgeDeck: true as boolean },
    /** STEP G6: the R6 (6-lane) roads from the G5 line set (src/roads/r6/R6LineData.ts, made by scripts/r6-export-line.ts), added together with the J1 arms and the island link (after the railway plan). First road: R6-2 (L65, south, 1.97 km, both ends free). false = none. */
    r6Roads: { enabled: true as boolean },
    /** STEP B7a-2 (21.6 build): the 7 NEW R6 lines R6-9 .. R6-15 (src/roads/r6/R6NewLineData.ts, made by scripts/centre-r6-export.ts, 21.45) as game roads, same section / speed / daylight as r6Roads. DEFAULT FALSE: the lines have free ends, no junction nodes and no structures yet (21.7 / 21.8), so they cross other roads without a junction. true only for a look in the game, never as the shipped state. */
    r6New: { enabled: true as boolean },
    /** STEP B7-3 (21.6 build, batch R4-a): the R4 lines of batches R4-a (R4-1 .. R4-8, R4-10, R4-11) and R4-b (R4-14 .. R4-18, R4-22, R4-25 .. R4-28) (src/roads/r4/R4NewLineData.ts, made by scripts/centre-r4-export.ts) as game roads, 4 lanes divided, V60, grade <= 6 %. Ends are free (no junction mouth, no structure yet, 21.61). false = none. */
    r4New: { enabled: true as boolean },
    /** STEP B7-4 (21.6 build, batch R2-a): the R2 lines of batches R2-a (R2-12 .. R2-18, R2-44, R2-63, R2-65) R2-b (R2-21 .. R2-30) and R2-c (R2-31, 32, 38, 39, 41, 46, 48, 49, 50, 66) and R2-d (R2-20, 34 .. 37 and 40 / 42 split at nodes, 45, 69, 75, 77) (src/roads/r2/R2NewLineData.ts, made by scripts/centre-r2-export.ts) as game roads, 2 lanes undivided, V40, grade <= 8 %. Ends are free (no junction mouth, no structure yet, 21.61). false = none. */
    r2New: { enabled: true as boolean },
    /** STEP CRR-5b: the 5 rail-corridor roads (4 lanes, pier row = median 6.4 m, 22.4 m wide; centreline = fixed data src/roads/crr/CorridorRoadData.ts, made by scripts/crr-export-data.ts) as game roads. They join AFTER the railway and the J1 arms exist (RoadNetwork.addCorridorRoads, called by TerrainGenerator), so the rail plan never sees them. DEFAULT FALSE until the user has seen it in the game. NO junction pad / traffic link / median mesh yet (CRR-5c, CRR-3). */
    corridorRoads: { enabled: true as boolean, maxGrade: 0.06, smoothHalf: 45 },
    /** STEP HK-8d-1: the Hatikamrul-type interchange at the ring S node (HANDOFF_HATIKAMRUL.md). ON = the ring uses the raised profile src/roads/ring/RingProfileData.hk.ts (ring OVER the arm / link, deck top 27.23 m at the node, HK-6 patch). DEFAULT FALSE: nothing changes until the structures, ramps and loops are in (HK-8d-2 ... HK-13). */
    hatikamrul: { enabled: true as boolean },
    /** STEP B7-5 (21.6 build, batch C-a): the C lines C-2 .. C-13 (src/roads/c/CNewLineData.ts, made by scripts/centre-c-export.ts) as game roads, collector street 2 lanes undivided, V40, grade <= 8 %, no footpath yet. Ends are free (no junction mouth, no structure yet, 21.61). false = none. */
    cNew: { enabled: true as boolean },
    /** STEP B7-6 (21.6 build, batch L-a): the L lines L-1 .. L-4, L-7 .. L-12 (src/roads/l/LNewLineData.ts, made by scripts/centre-l-export.ts) as game roads, local street 2 lanes undivided, V30, grade <= 10 %, no footpath yet. Ends are free (no junction mouth, no structure yet, 21.61). false = none. */
    lNew: { enabled: true as boolean },
    /** STEP CITY-SHP-2 (user order 2026-11-20): the user's drawn city streets (City_Road.shp, 17 streets after 8 joins; src/roads/city/CityShpLineData.ts, made by scripts/city-shp-fit.ts MODE=export) as game roads, 2 lanes undivided: class C (V40, grade <= 8 %) and class L (V30, grade <= 10 %), same sections as the C / L lines. Heights are PROVISIONAL (terrain-following, grade-limited; the real vertical profile is step R4). Ends are free (no junction mouth, 21.61). false = none. */
    shpCity: { enabled: true as boolean },
    /**
     * STEP RAIL-B2: ONE place for the road / rail buffer (m). Used by scripts/road-rail-buffer-check.ts (measure only; the design code does not read it yet).
     *   railOverRoad   : rail over a road: underside of the rail deck above the road surface.
     *   roadOverRail   : road over the rail: road surface above the top of the rail.
     *   pierToDeckEdge : plan distance from a rail pier to the edge of a road deck (carriageway + shoulder).
     *   armPierToRailPier : plan distance between a pier of a J1 arm structure and a rail pier.
     */
    roadRailBuffer: { railOverRoad: 7.0, roadOverRail: 9.0, pierToDeckEdge: 3.0, armPierToRailPier: 3.0 },
    /** The long bridge to the island and the island's road network (RoadPlan.ISLAND_PLAN). */
    island: false,
    /**
     * INTERCHANGES (src/interchange, docs/INTERCHANGE_SYSTEM_BN.md). ON for testing (set false to go back): with enabled = false (or an empty list) the road network is exactly as before.
     * Every entry: where (x, z in world metres, yaw = world heading of the main road at the centre, atan2(dz, dx)), the pattern ('diamond' | 'cloverleaf' | 'parclo'), the section of the
     * two roads ('highway' | 'arterial' | 'avenue', = roads/RoadSection.ts), optionally which road is the bridge and the ground height `y` (default: the road surface under the centre).
     * STEP 2b: only the RAMP ROADS are added (ribbon + terrain cut). Bridge deck / junction pads / AI / look come in the next steps.
     */
    interchange: {
      enabled: false as boolean,
      list: [] as { id: string; pattern: string; x: number; z: number; yaw: number; main: 'highway' | 'arterial' | 'avenue'; cross: 'highway' | 'arterial' | 'avenue'; upper?: 'main' | 'cross'; y?: number }[],
    },
    /**
     * SCENARIOS (src/interchange/scenario, docs/j6/03_SCENARIO_SPEC_BN.md). ON for testing (set false to go back): with enabled = false the road network is exactly as before (every road, pad, bridge identical).
     * ON: the listed scenarios (ids of SCENARIOS) edit the generated roads (cut road ends, add roads) BEFORE the junction pads are made, so pads / bridges / traffic graph see the result.
     */
    scenario: {
      enabled: false as boolean, // J6 scenario OFF (no roads) -- was ON for in-game testing (T01 placeholder alignment). false = the original game, exactly.
      list: ['J6'] as string[],
    },
  },

  /** STAGE 10: the city (local streets, then buildings). */
  city: {
    /** STEP 3 (user order 2026-11-20): land plots beside the 17 city streets (src/buildings/PlacementsPlots.ts, made by tools/city-plots-plan.py): boundary wall, gate on the road side only, trees inside, and the existing building models (university, college, madrasah, mosques, schools, offices, hospital, police ...) standing in them. The old hospital is replaced by the one in its plot and the fill houses inside a plot are dropped. false = none of it. `vacant` (2026-11-20, user): the empty plots of the 860 plot map (src/buildings/PlacementsVacant.ts, scripts/city-vacant-build.ts): boundary wall, gate on the road side only, small and big trees inside; false = none of them. */
    plots: { enabled: true as boolean, vacant: true as boolean },
    /** ROADSIDE ROWS (user order 2026-11-21): buildings in tidy rows beside the roads of the city area (src/buildings/PlacementsRoadside.ts, scripts/city-roadside-build.ts): big offices / university / hospital beside the 8-lane roads, offices, shops, flats beside the 4-lane and 2-lane roads. The scattered city-fill buildings inside the city circle are dropped. false = the old scattered fill, none of the rows. */
    roadsideBuildings: true as boolean,
    /**
     * ROADS STEP 1: the cross-section of every road kind, ONE source (roads/RoadSection.ts reads it, scripts/road-section-check.ts checks it).
     * Metres. A DIVIDED section (median) is built from these numbers: halfWidth = median half + median-side shy + lanes x laneW + kerb-side shy.
     *   highway   = every old 4-lane main road, now 3 + 3 lanes with a 2.0 m planted median.
     *   arterial  = 2 + 2 lanes with a 1.5 m median (was one wide 11 m carriageway).
     *   avenue    = the 4-lane downtown streets, now 3 + 3 lanes of 3.25 m (40 km/h town street) with a 1.5 m median.
     * collector and local keep their old half width (terrain, junction pads, street plan and buildings were made for it), so they are
     * "undivided": only lane and footpath numbers are listed, for the checks.
     * footpath (verge + walk + kerb) is the TARGET used in Step 3 (raised footpath). In Step 1 the drawn footpath is still roadside.sidewalk.
     */
    roadSections: {
      highway: { lanesPerDir: 3, laneW: 3.5, shyMedian: 0.5, shyOuter: 0.5, medianClear: 2.0, medianKerb: 0.2, kerbH: 0.15, kerbW: 0.2, verge: 1.5, walk: 2.0, fall: 0.02, designKmh: 100 },
      arterial: { lanesPerDir: 2, laneW: 3.5, shyMedian: 0.5, shyOuter: 0.5, medianClear: 1.5, medianKerb: 0.15, kerbH: 0.15, kerbW: 0.2, verge: 1.5, walk: 2.0, fall: 0.02, designKmh: 70 },
      avenue: { lanesPerDir: 3, laneW: 3.25, shyMedian: 0.5, shyOuter: 0.5, medianClear: 1.5, medianKerb: 0.15, kerbH: 0.15, kerbW: 0.2, verge: 1.5, walk: 2.0, fall: 0.02, designKmh: 40 },
      collector: { lanesPerDir: 1, laneW: 3.25, kerbH: 0.15, kerbW: 0.2, verge: 1.5, walk: 2.0, fall: 0.02, designKmh: 50 },
      local: { lanesPerDir: 1, laneW: 3.0, kerbH: 0.15, kerbW: 0.2, verge: 1.2, walk: 2.0, fall: 0.02, designKmh: 30 },
    },
    /** ROADS STEP 2: the physical median (kerbs + soil strip as a companion mesh, invisible collider so cars cannot cross). Used by roads/MedianPlan.ts, MedianView.ts, MedianPhysics.ts. */
    median: {
      /** Sample spacing (m) along the road for the mesh and the collider pieces. */
      step: 3,
      /** The soil surface sits this far (m) below the kerb top. */
      soilDrop: 0.04,
      /** Height (m) of the median kerb (and so of the soil) above the road surface. 0.15 before, now 5x = 0.75. Used by MedianPlan, MedianView, medianSoilTop (hedges / trees stand on it). */
      height: 0.75,
      /** Height (m) of the invisible collider above the road surface: a little above `height` so a car cannot climb the tall kerb. */
      colliderH: 0.85,
      /**
       * Grass + flowers on the median soil: the GAME'S OWN grass (the same tuft models, wind and distance fade as the meadow grass, see GrassPlacement.placeMedian +
       * GrassManager flag 5), so no extra meshes and no new models. `perSeg` tufts per 3 m piece of median (x Quality grassMul), `flowerShare` = share of tufts that are
       * the game's wild flowers (buttercup, lavender, poppy, cornflower; no white ones).
       */
      grass: { enabled: true, perSeg: 18, flowerShare: 0.14 },
      /**
       * PEDESTRIAN CROSSINGS (zebra) with a gap in the median: one in front of each City Mall door (MALL_DOORS), on the nearest divided road within `maxDist` m
       * (people come from the parking lots across the road and must reach the mall). `gap` = length (m) of the opening in the median (rounded out to the 3 m sample grid),
       * `zebraLen` = length of the painted band along the road, `barW` / `barStep` = width and spacing (m) of the white bars across the road.
       * `extra` = more world points (x, z): a crossing is made at the nearest divided road to each. A crossing never lands in a junction or on a bridge.
       */
      crossing: { enabled: true, gap: 7, zebraLen: 3.2, barW: 0.5, barStep: 1.0, maxDist: 70, extra: [] as { x: number; z: number }[] },
      /** The median ends this far (m) beyond the junction pad core (rCore). Hedges stop at 9, trees at 16, so the planting is always inside the median. */
      padMargin: 8,
      /** Length (m) of the rounded nose at each end of a median piece. */
      noseLen: 3,
      /** Shortest median piece (m); anything shorter is left flat. */
      minRun: 12,
      /** The median mesh is drawn within drawRadius x this (m). */
      drawRange: 0.7,
      /** Physics cells (m): colliders are made per cell, only near the player. */
      cell: 125,
      /**
       * 6-LANE x 6-LANE JUNCTIONS (two different 3 + 3 lane roads, highway / avenue, meeting): the raised median, its hedges, trees, grass and lamps stop `extra` m earlier
       * than at other junctions (on top of padMargin), so the junction is open. Other junctions keep the old behaviour. `minAngleDeg` = two six-lane arms closer to a straight
       * line than this (degrees) are one road continuing and do not make a 6 x 6 junction. enabled = false brings the old behaviour back everywhere.
       */
      sixLaneJunction: { enabled: true, extra: 14, minAngleDeg: 30 },
    },
    /**
     * ROADS STEP 4: U-turn openings in the median of the divided roads (highway, arterial, avenue). One opening serves both directions: a car in the kerb lane swings
     * right through ALL lanes and the gap into the kerb lane of the opposite carriageway (a half circle of radius = kerb-lane centre). Used by roads/UTurns.ts,
     * MedianPlan.ts (cuts the median), MedianView.ts (asphalt patch + broken yellow lines), Roadside.ts (no tree / hedge in the gap), traffic/Route.ts + AIDriver.ts.
     */
    uturn: {
      enabled: true,
      /** Wish distance (m) to the next opening along one road: random in [gapMin, gapMax]; two openings of one road are never closer than hardMin. */
      gapMin: 500,
      gapMax: 800,
      hardMin: 300,
      /** An opening is at least padMin m from a junction pad core; it prefers padMin..padMax (a car that just came out of a junction can turn back). */
      padMin: 60,
      padMax: 100,
      /** Length (m) of the gap, nose tip to nose tip (rounded up to the median sample step). 12..25 m. */
      len: { highway: 24, arterial: 20, avenue: 18 },
      /** No bridge within this distance (m) of the gap, and the road must be straight enough (max heading change in degrees over gap + 2 x 20 m). */
      bridgeClear: 15,
      maxBendDeg: 20,
      /** Median trees and hedges stop at least this far (m) from each nose tip. The real low-planting sight zone is `planting.sightZone` (ROADS STEP 5), usually longer. */
      plantClear: 8,
      /** AI: chance (0..1) that a driver who reaches an opening turns round there, speed (m/s) of the half circle, free space (m) kept beside the vehicle's outer body, gap time (s) to traffic. */
      useChance: 0.3,
      turnSpeed: 5,
      sideMargin: 3,
      gapSeconds: 5.5,
      /** Asphalt patch + broken yellow line of an opening: patch half width beyond the median kerb (m), the yellow line dash / gap (m), patch lift over the road (m). */
      patchBeyond: 0.62,
      dash: 3,
      lift: 0.03,
      /** ROADS STEP 6b: the U-turn sign (blue board on a median pole), `before` m ahead of the nose of every opening for each direction; no pole within `lampClear` m of a median lamp. */
      sign: { enabled: true, before: 40, lampClear: 4, boardBottom: 2.0, showRadius: 900 },
    },
    /**
     * ROADS STEP 5: planting of the divided roads (roads/Planting.ts, Roadside.ts, StreetLights.ts, vegetation/GrassPlacement.ts). Everything uses the game's own models
     * (small debdaru / date palm, the flowering hedge piece, the meadow grass tufts): no new models.
     */
    planting: {
      /**
       * D7, sight zone: this far (m) on each side of a U-turn opening (measured from the nose tip) the median carries NO tree and NO hedge, only low grass (tufts x `grassScale`),
       * so a driver can see a car waiting in the gap. Per road kind (avenue = the 40 km/h downtown street). The stopping sight distance of the audit was 46 / 104 / 183 m
       * (40 / 70 / 100 km/h): 65 m is a compromise, raise it here if you want the full distance.
       */
      sightZone: { highway: 65, arterial: 65, avenue: 45 },
      /** Scale of the median grass tufts inside a sight zone (1 = normal, normal tufts are 0.7..1.5). */
      grassScale: 0.55,
      /**
       * Median OUTSIDE the cities (it had grass only): hedge blocks `hedgeOn` m long with a `hedgeOff` m gap (glare screen, deterministic), and a small tree at `treeKeep` (0..1) of the
       * city tree places (so about every 60 m). Inside the cities the old dense planting stays.
       */
      countryMedian: { enabled: true, hedgeOn: 24, hedgeOff: 10, treeKeep: 0.5 },
      /**
       * Double-arm street lamps on the median of every divided road (one pole, an arm over each carriageway): spacing (m) along the median per road kind (x the quality lamp
       * spacing), light pool radius (m), pole height scale. The old lamps on the outer footpath / shoulder stay (they light the kerb lane). `clearEnds` = no lamp this close (m)
       * to the end of a median piece (nose, junction, U-turn gap); `treeClear` = no median tree this close (m) to a lamp.
       */
      medianLamps: { enabled: true, step: { highway: 33, arterial: 31, avenue: 28 }, pool: { highway: 12, arterial: 10.5, avenue: 9.5 }, scale: { highway: 1.25, arterial: 1.1, avenue: 1.0 }, clearEnds: 9, treeClear: 4.5 },
    },
    /**
     * ROADS STEP 3: the raised footpath of city roads (companion mesh on the ribbon strip beside the asphalt, collider, dropped kerbs, gully grates).
     * Its WIDTH is still the ribbon strip of Step 1 (roadside.sidewalk = 3 m): the 3.7 m target of the design table would move buildings (decision D10).
     */
    footpath: {
      /** Kerb height (m) above the road surface, kerb stone width (m), and cross-fall of the walking surface towards the road. */
      height: 0.15,
      kerbW: 0.2,
      fall: 0.02,
      /** Sample spacing (m) of the mesh and collider; the first / last piece of every run is the dropped kerb (ramp from 0 to full height over one step). */
      step: 3,
      /** The footpath ends this far (m) beyond the junction pad core. Tree pits stop at 5, so the pits are always inside the footpath. */
      padMargin: 2,
      /** Shortest footpath piece (m). */
      minRun: 9,
      /** Pedestrian walk line: distance (m) from the kerb face. Pits occupy 0.15..1.35 m, so people walk behind them. */
      walkOffset: 2.2,
      /** Gully grate spacing (m) along each kerb, and its size (m, along the road x across). */
      gullyStep: 28,
      gullySize: [0.55, 0.38] as [number, number],
      /** The mesh is drawn within roadside.drawRadius x quality x this (m). */
      drawRange: 0.6,
      /** Physics cell size (m). */
      cell: 125,
    },
    /**
     * ROADS STEP 6b: zebra crossings in the middle of a block on the UNDIVIDED city roads (local streets and collectors inside a city). Divided roads keep the mall crossings of
     * `median.crossing`. Every crossing (both kinds) breaks the raised footpath: `breakHalf` m each side of its centre the footpath is level with the road (a dropped kerb at both
     * ends of the break), and no lamp stands there. The painted zebra reuses `median.crossing` (zebraLen, barW, barStep).
     * `spacing` = distance (m) between two crossings of one road (min..max, hash chosen), `padClear` = nearest distance to a junction pad, `endClear` = to a road end,
     * `gap` = length (m) of the asphalt patch along the road (hides the dashed centre line), `maxBend` = largest direction change (cos) across 12 m.
     */
    streetCrossing: { enabled: true, spacing: [140, 230] as [number, number], padClear: 45, endClear: 30, gap: 4, breakHalf: 2.6, minBendCos: 0.985 },
    localRoads: {
      /** City sites that get local streets so far (Stage 10B step 1 = site 0 only; sites 1 and 2 follow). */
      sites: [0] as number[],
      /** Shortest street piece (m); the junction system needs legs of at least `minArm`. */
      minEdge: 60,
      /** Shortest connector to a main road (m): a local pad and a main-road T pad must not overlap. */
      minConnect: 82,
      /** Longest connector (m) built to join a street group to the network. */
      maxConnect: 420,
      /** Extra connectors to main roads are built for street nodes closer than this (m). */
      extraConnect: 240,
      /** Spacing (m) along a tier 1-3 road between two local T-junctions. */
      mainTSpacing: 120,
      /** Nothing is built within this distance (m) of an existing junction of tier 1-3 (its pad is large). */
      junctionKeepout: 80,
      /** Bridges: no local street within this distance (m). */
      bridgeKeepout: 130,
      /** Free ground (m) between a local street edge and a main-road edge / another street edge. */
      clearMain: 14,
      clearLocal: 24,
      /** Wet test margin (m above the water surface) and sample spacing (m) along a street. */
      wetMargin: 2.5,
      sampleStep: 8,
      /** Steepest allowed street (rise / run). */
      maxGrade: 0.06,
      /** Grade limit (rise / run) the junction system may use to ramp a street back onto its profile after a level pad. */
      rampGrade: 0.1,
      /** Cross slope a pad between local streets may have (rise / run); its plane is fitted through the streets. */
      padTilt: 0.06,
      /** A connector stays level for this length (m) at its T-junction with a main road (the length of the pad stub). */
      mainPlateau: 28,
      /** A T-junction meets the road at least this far from parallel (|cos| of the angle to the road <= value). */
      maxCosSkew: 0.35,
      /** Streets keep this far (m) from the border of their area. */
      areaMargin: 6,
      /** Junction pad limits for local streets (Junctions.ts): shortest leg, spacing local-local, spacing local-main. */
      minArm: 40,
      minPadSpacing: 48,
      mixedPadSpacing: 76,
      /** Footpath (sidewalk) width beside local streets (m) used for the CLEARANCE tests of the street planner (kept at 2 so the street plan does not change). */
      sidewalk: 2,
    },
    /**
     * CITY ROADSIDE (Roadside.ts, RoadMesh / RoadMaterial city style). Only roads inside a planned city area (CityPlan.siteAt) get it:
     * paved interlocking-tile sidewalk `sidewalk` m wide on both sides (this is the ribbon shoulder of a city road), a kerb, a lawn strip behind
     * the sidewalk (grass, see vegetation.grass.city), trees in square kerbed pits every `treeSpacing` m, low flowering hedges (`hedge`) along
     * medians and parking edges, street lamps (StreetLights, on the sidewalk).
     */
    roadside: {
      sidewalk: 3,
      /** Tree pits: spacing range (m) along each sidewalk, pit side (m, kerbed square), distance of the pit centre from the asphalt edge (m). */
      treeSpacing: [30, 42] as [number, number], // ROADS STEP 5: was [45, 60] (street trees were far apart and few)
      /** Street tree size (scale of the normal tree models; small young trees) and colour multiplier (low = deep dark green; normal forest trees are 0.82-1.14). */
      streetTree: { scale: [0.42, 0.6] as [number, number], tint: [0.58, 0.7] as [number, number] },
      pitSize: 1.2,
      /** Pit centre distance from the asphalt edge: 0.75 = the pit stands on the KERB side of the 3 m footpath (a 1.2 m pit then covers 0.15-1.35 m), so the walking strip (pedestrians walk at ~1.85 m) and the lamp poles (2.1 m) stay free. It was 1.0 = the pit sat in the middle of the footpath. */
      pitOffset: 0.75,
      /** Low flowering hedge: height range (m), width (m), spacing of the instances (m) along the line, length of one hedge piece (m, a little more than the spacing so pieces overlap). */
      hedge: { hMin: 0.6, hMax: 0.9, width: 0.8, step: 2.6, pieceLen: 3.1 },
      /** Hedge / pit / shrub / guardrail instances are drawn within this distance (m) of the player (they live in 500 m chunk groups that are shown / hidden at 2 Hz). */
      drawRadius: 380,
      /** Yellow-black striped kerb at the median: stripe length (m) and kerb width (m). */
      kerbStripe: 0.7,
      kerbWidth: 0.35,
      /** Paving tile size (m) of the interlocking pavers (shader). */
      paver: 0.24,
    },
    /**
     * HIGHWAY ROADSIDE outside the cities (Roadside.ts): galvanized W-beam guardrail on embankment and curve sides (posts every `postStep` m),
     * a dirt / gravel shoulder `shoulder` m wide instead of grass, then tall grass clumps and shrubs on the verge (grass patch, see
     * vegetation.grass.verge) and street lights on one side.
     */
    highway: {
      postStep: 4,
      /** Guardrail goes up where the ground beside the road drops more than `dropMin` m within 6 m, or where the road bends tighter than `curveRadius` m. */
      dropMin: 0.8,
      curveRadius: 900,
      shoulder: 1.5,
      railHeight: 0.75,
      /** Lamps on one side only: spacing (m) is the normal highway lamp class spacing times this. */
      lampStepMul: 1.4,
      /** Verge shrubs (the model of the city hedge, bigger): spacing range (m) along each side, distance range (m) beyond the shoulder, scale range. */
      shrubSpacing: [7, 16] as [number, number],
      shrubOffset: [1.4, 6.5] as [number, number],
      shrubScale: [0.8, 1.7] as [number, number],
    },
  },

  /** STAGE 7: vegetation. Step 1 = forest trees (instanced, placed in the chunk worker). */
  vegetation: {
    /** Chunks up to this LOD get trees (0 = nearest only). LOD 0 uses the detailed models, higher LODs the simple ones. */
    maxLod: 1,
    /** Trees and rocks cast shadows into the shadow map. false = no tree shadows (the shadow pass draws every tree a second time: the biggest tree cost, makes the PC hot). */
    treeShadows: false, // runtime: ShadowManager switches it on at shadow level medium and high (setTreeShadows)
    /** Placement grid (m). One tree at most per cell, jittered inside it. 500 / cellSize must be a whole number. */
    cellSize: 10,
    /** Chance (0..1) of a tree per cell: in the middle of a forest / in open land. */
    forestChance: 0.8, // 2026-11-23: was 0.4 (dense trees everywhere)
    scatterChance: 0.3, // 2026-11-23: was 0.02 (open land gets trees too, not only forests)
    /** 2026-11-23: AGRICULTURE AREAS (FarmAreas.ts) are completely tree-free: no tree of any source inside the circle + this margin (m). */
    farmTreeClear: 8,
    /** Size (m) of the forest patches (noise wavelength). */
    forestScale: 520,
    /** No tree on ground steeper than this (degrees), the chance fades out from 60 % of it. Was 33: over 60 % of the ground above 200 m is steeper than that, so the hills were bare. */
    maxSlopeDeg: 42,
    /** Free ground (m) above the water surface / above sea level (beach). */
    waterMargin: 1.5,
    seaMargin: 3.5,
    /** Free ground (m) around asphalt, shoulder and junction pads. */
    roadClear: 4,
    /** Trees thin out between these heights (m) and stop above the second one (snow line is ~340 m). Was 230 / 330: the upper half of the hills was bare. */
    treeLineStart: 320,
    treeLineEnd: 420,
    /** Pines replace broadleaf trees between these heights (m); palms grow below `palmBelow` (m). */
    pineFrom: 70,
    pineFull: 150,
    /** 2026-11-23: the share of pines never goes above this (was 100 % on high hills: the hills were all one tree). */
    pineMax: 0.45,
    /** HILLS (above `from` m): this share of the non-big, non-pine trees is the slim debdaru instead of a broadleaf shape. */
    hill: { from: 40, debdaru: 0.2 },
    /** MEGA TREES: a big forest species grown to `scale` (same model, bigger: thick and tall; 1 = 20-30 m). `patchChance` inside noise patches (`patchScale` m, noise above `patchFrom`), `chance` elsewhere. */
    mega: { chance: 0.006, patchChance: 0.08, patchFrom: 0.1, patchScale: 170, scale: [1.9, 2.5] as [number, number] },
    palmBelow: 35,
    /** BIG FOREST TREES (sal, segun, koroi, bot, shimul) in the middle of a forest: share among the forest trees (0..1) and scale range (1 = mature 20-30 m tree). */
    /** Every tree colour is multiplied by this (r, g, b): the leaves were too light / yellow-green; lower = darker, red lower than green = bluer, deeper green. */
    leafDark: [0.82, 0.93, 0.82] as [number, number, number],
    /** Minimum lit colour of tree leaves in shade (r, g, b x leaf colour x daylight): lower = darker / blacker shade, 0 = off. */
    shadeFloor: [0.34, 0.44, 0.3] as [number, number, number],
    bigTreeChance: 0.45,
    bigTreeScale: [0.7, 1.3] as [number, number],
    /** 2026-11-20: size multiplier of the trees OUTSIDE the dense jungle (forest, open land, village trees): ordinary trees x `treeSizeOutside`, the big species (sal, segun ...) x `treeSizeOutsideBig` (so they do not get taller than ~40 m). The jungle trees keep their size (1 = no change). */
    treeSizeOutside: 1.8,
    treeSizeOutsideBig: 1.3,
    /** 2026-11-21: SMALL TREES (broadleaf, oak, vase, slender lower than `maxHeight` m): only `keep` (0..1) of them are placed (a fixed share per spot, so none ever flickers or moves). 1 = all (as before), 0.25 = a quarter. Taller trees, palms, bamboo, city trees are not touched. */
    smallTrees: { maxHeight: 10, keep: 0.5 },
    /** HOMESTEADS (gram): coconut, date, palmyra palms and banana clumps stand around rural houses. `reach` = ring width (m) beyond the footprint, `chance` per 10 m cell next to the house (fades out to the edge of the ring). */
    homestead: { reach: 32, chance: 0.42 },
    /** POND / LAKE / RIVER BANKS: palms and banana on low land within `reach` m of water. `chance` per 10 m cell, `maxHeight` = only land lower than this (m above sea level). */
    bank: { reach: 9, chance: 0.12, maxHeight: 40 },
    /**
     * BAMBOO GROVES (bash jhar): patches of low, damp land (noise wavelength `scale` m; the patch starts where the noise passes `from` and is full at `full`)
     * covered with bamboo clumps: `chance` per 10 m cell in the heart of a grove. Only land lower than `maxHeight` m, gentle slopes (`slopeMax` = share of the
     * normal slope limit). Scale range of a clump (1 = grown, ~12 m). `homestead` / `bankShare` = the share of bamboo among the homestead / bank trees.
     */
    bamboo: { scale: 300, from: 0.3, full: 0.62, chance: 0.4, maxHeight: 60, slopeMax: 0.55, clumpScale: [1.1, 1.7] as [number, number], homestead: 0.1, bankShare: 0.15,
      /** 2026-11-21: share of bamboo among the young trees of the jungle thicket (was 0.1 = bamboo clumps everywhere, and small). */
      thicketShare: 0.015,
      /** BAMBOO IN THE DENSE JUNGLE: a clump there is `jungleTall[0]..[1]` times taller (random per clump), fading in with the jungle density (0 outside, full inside); 1 = no change. Its width grows much slower (see `treeWidth`). */
      jungleTall: [2, 3.4] as [number, number] },
    /**
     * DENSE FOREST (ghono bon): the forest districts of the world map (WorldRegions kind 'forest') are covered with a jungle: nearly every 10 m cell has a
     * canopy tree (`chance`, `bigChance` = share of the five big forest trees), and a second, younger tree grows in the shade of it (`understory` chance per
     * cell, scale range, `bambooShare` of them are bamboo clumps on low land, `bigShare` = young big trees). The jungle fades out over `fade` m at the district edge
     * (a ragged edge). Lower `understory` (and `chance`) if the frame rate drops: they are the number of trees.
     */
    dense: { farKeep: 0.6, fade: 260, chance: 0.95, bigChance: 0.62, understory: 0.55, understoryScale: [0.8, 1.2] as [number, number], bambooShare: 0.04, bigShare: 0.1,
      /**
       * JUNGLE THICKET (ghono jongol, 2.5x): `layers` more spots in every jungle cell (each its own random stream, `chance` x jungle density x Quality treeMul),
       * so the jungle holds about 2.5x as many plants as before. `undergrowth` = share of them that are lata-pata (fern / shrub / creeper mound, no colliders),
       * the rest are young trees of `scale` (x the tree's normal size). Lower `layers` / `chance` if the frame rate drops.
       */
      thicket: { layers: 6, chance: 0.95, undergrowth: 0.65, scale: [0.85, 1.3] as [number, number] },
      /**
       * JUNGLE VINES (2026-11-21, like a real rain-forest photo): per 10 m jungle cell (x jungle density x Quality treeMul) `lianaChance` = a curtain of hanging woody vines
       * (8-12 m, TreeKind.liana) and `tangleChance` = slim leaning stems with a diagonal limb across them (TreeKind.tangle). No colliders. Near chunks only (LOD 0).
       * Every liana is ~300 triangles, every tangle ~600: lower the chances (or set 0 = off) if the frame rate drops.
       */
      vines: { lianaChance: 0.14, tangleChance: 0.09, /** 2026-11-22: vines only in PATCHES (not all over the jungle): `scale` m = size of the noise field, `from` .. `full` = noise range that grows from nothing to a full patch (higher `from` = fewer / smaller patches), `boost` = chance multiplier inside a patch (so a patch is denser than before). the noise is about -0.7..0.7 (median 0): `from` -1 + `boost` 1 = the old everywhere-look. */ patch: { scale: 110, from: -0.25, full: 0.1, boost: 3 }, lianaScale: [0.8, 1.3] as [number, number], tangleScale: [0.8, 1.4] as [number, number] },
      /**
       * JUNGLE DEADWOOD (sukno gach + sukno pata): old dry trees lying on the ground and patches of dry fallen leaves. Per 10 m jungle cell (x jungle density x Quality treeMul):
       * `logChance` = a fallen dead tree (`logScale` = size range, 1 = 7 m long), `litterLayers` x `litterChance` = loose leaf patches (`litterScale`), and `aroundLog` leaf patches
       * are heaped along every fallen tree. No colliders. Lower `litterChance` / `aroundLog` if the frame rate drops (every patch is ~40 small cards).
       */
      deadwood: { logChance: 0.13, logScale: [0.75, 1.3] as [number, number],
      /** 2026-11-21: fallen leaves lie in HEAPS: `litterLayers` heap spots per cell x `litterChance`, a heap = `clusterLeaves` leaves within `clusterRadius` m; `loneChance` = chance of one lone leaf per cell. */
      litterLayers: 3, litterChance: 0.7, clusterLeaves: [8, 20] as [number, number], clusterRadius: [0.8, 2.0] as [number, number], loneChance: 0.45, litterScale: [0.8, 1.4] as [number, number], aroundLog: 10 } },
    /**
     * EXTRA JUNGLE SPOTS (ghono jongol outside the forest districts): round patches that use the SAME dense jungle as above (same chance, big trees, understory,
     * tall bamboo, grass thinning). `r` = radius (m) of the full jungle, `fade` = the ragged edge fades out over this many m outside the full part (smoothstep, like the district edge).
     * A: coast side (east-hills-south / southeast-coast). B: beside the river (west-delta). Beach, water, steep slope, roads and plots are still cut out by the tree tests.
     */
    jungleSpots: [
      { id: 'A-coast', x: 4769, z: 2296, r: 900, fade: 250 },
      { id: 'B-river', x: -2718, z: 1167, r: 800, fade: 250 },
    ] as Array<{ id: string; x: number; z: number; r: number; fade: number }>,
    /** Tree chance (0..1 of the normal chance) inside a planned city area, by zone kind. Unlisted zones get no trees. */
    cityZoneChance: { green: 0.6, recreation: 0.7 } as Record<string, number>,
    /** Outside the plan of a city the forest grows back over this distance (m). */
    cityFadeOut: 150,
    /** Wind sway (m of sway per metre of tree height). */
    windStrength: 0.02,
    /** Wind gusts (seconds): no wind most of the time; a gust blows for lenMin..lenMax s (smooth rise / fall), then calm for calmMin..calmMax s (about 1 minute of wind per 10 minutes). First gust comes firstMin..firstMax s after the start. */
    gust: { firstMin: 20, firstMax: 240, lenMin: 45, lenMax: 80, calmMin: 360, calmMax: 780, rise: 10, fall: 14 },
    /** Trunks are sunk this far (m) into the ground so coarse LOD terrain never leaves them floating. */
    sink: 0.35,
    /** Trunk colliders (Rapier cylinders): created for trees within `collideRadius` (m) of the player, removed beyond `collideKeep`. */
    collideRadius: 50,
    collideKeep: 70,
    /** Trees are grouped in squares of this size (m) - one fixed body per square. Chunk size / this must be a whole number. */
    collideCell: 50,
    /** Max squares given colliders per physics update (5 Hz), so walking into a forest never hitches. */
    collideBuildPerTick: 8,
    /**
     * TREES ARE REAL: only the TANK (and blasts) fell trees. Cars, buses, trucks, people hit a trunk like a solid object (normal crash physics).
     * Only a trunk thinner than `passRadius` (m) or a tree lower than `passHeight` (m) (saplings, tiny shrubs) has no collider.
     * `breakRadius` / `breakSpeed` / `treeDensity` / `treeLen` are no longer used by normal vehicles (kept for TreeDestruction.crashInBox).
     */
    passRadius: 0.05,
    passHeight: 0.6,
    breakRadius: 0.45,
    breakSpeed: 4,
    treeDensity: 650,
    treeLen: 4,
    /** Rocks: boulders and outcrops, placed like trees. Rocks at least `collideMinHeight` (m) tall collide (smaller ones can be stepped over). */
    rocks: {
      cellSize: 20,
      baseChance: 0.05,
      /** Extra chance on slopes (rise / run 0.35 .. 0.8) and above the tree line (240 .. 380 m). */
      outcropChance: 0.5,
      alpineChance: 0.25,
      maxChance: 0.6,
      roadClear: 5,
      waterMargin: 0.4,
      minHeight: 1.5,
      collideMinHeight: 0.45,
    },
    /** Grass: tufts in tiles around the player (made by the chunk workers on request), fading out with distance. */
    grass: {
      /** Tile size (m) and cell size (m): one tuft at most per cell. tile / cell must be a whole number (and every LOD stride must divide it). 0.25 m = 1.6x denser than 0.32 (short grass needs many tufts to cover the ground). */
      tile: 32,
      cell: 0.5, // was 0.2: 6x fewer cells. 32 / 0.5 = 64, strides 1, 2, 4 divide it
      /**
       * DENSE SINGLE GRASS: every accepted meadow cell grows `dense` single tufts instead of one (7.5 = 7.5x the old density, may be fractional; same cell test, terrain test and
       * deterministic jitter, so the far rings stay a subset of the near ring). The Quality preset sets the value the workers use (low 3, medium 4.5, high 7.5).
       * Far rings (stride > 1) get dense / stride^2 (at least 1). Not applied to the mown city lawn.
       */
      dense: 1, // 1 = no extra tufts at all (was 7.5)
      /** 2026-11-23: GRASS ONLY IN THE DENSE JUNGLE: outside it (jungle density <= `jungleMin`) no tuft and no clump grows (the mown city lawn and the road median keep their own rules). `jungleDenseMul` = the extra-tuft count (Quality `dense`) is this many times higher inside the jungle. */
      jungleOnly: true,
      jungleMin: 0.05,
      jungleDenseMul: 5,
      /**
       * The extra (dense) tufts fade out with the camera distance: full size inside `denseFade[0]` m, shrunk to nothing at `denseFade[1]` m (smooth, no
       * pop), and a tile's extra tufts are not drawn at all when the tile is farther than `denseFade[1]` m. So the 5x density costs only near the player.
       */
      denseFade: [12, 26] as [number, number],
      /** Tiles within `radius` (m) of the player exist, tiles beyond `keep` are removed. */
      radius: 35, // only grass within 35 m exists (was 115)
      keep: 45,
      maxInFlight: 2, // at most 2 tiles asked from the workers at once (was 6): no CPU spikes
      /** Tufts shrink to nothing between these camera distances (m): only at the very edge, so the meadow is always there (like the trees). */
      fadeStart: 22,
      fadeEnd: 33,
      /**
       * SIZE OF THE GRASS. Short, dense grass: a tuft's TALLEST blade is `tuft.maxHeight` m at most (so the blades of a meadow are 1-20 cm); `tuft.min` = the
       * shortest tuft as a share of that (0.2 -> 4 cm). Big clumps (tussocks) are at most `clump.maxHeight` (0.5 m). `widthScale` = how wide a tuft is relative
       * to its height scale (blades lean outwards, so 2.2 gives natural short grass; higher = flatter, wider mats).
       */
      tuft: {
        /** Meadow single grass: tallest blade 0.8 m. */
        maxHeight: 0.24, // 2026-11-23: grass 0.25x smaller / finer (was 0.95)
        min: 0.2,
        /** Wildflowers keep 2x the old height (0.4 m). Mown city lawn keeps its old size (0.2 m, then x `city.height`) and its old width scale. */
        flowerMaxHeight: 0.24, // 2026-11-23: 0.25x (was 0.95)
        lawnMaxHeight: 0.2,
        lawnWidthScale: 2.2,
      },
      /** Width of every tuft = its height scale x this. */
      widthScale: 1.25, // wider tufts (was 0.8); was 2.2 when the grass was 3x lower: the tuft is 3x taller but only ~1.5x wider, so the blades stand more upright instead of splaying
      /**
       * Grass LOD rings (like the trees): `to` = up to this distance (m, nearest edge of the tile), `stride` = only every n-th cell gets a tuft
       * (must divide tile / cell = 128: 1, 2, 4), `density` = blades per tuft model, `size` = width of a tuft (fewer tufts, each a bit wider).
       * Far rings have no flowers. The tuft positions of a coarse ring are a subset of the near ring, so nothing jumps when a tile changes ring.
       */
      lods: [
        { to: 10, stride: 1, density: 1, size: 1, clumpStride: 1, clumpDensity: 1, clumpSize: 1 },
        { to: 20, stride: 2, density: 0.5, size: 1.4, clumpStride: 1, clumpDensity: 0.6, clumpSize: 1 },
        { to: 35, stride: 4, density: 0.25, size: 2, clumpStride: 2, clumpDensity: 0.35, clumpSize: 1.35 },
      ] as { to: number; stride: number; density: number; size: number; clumpStride: number; clumpDensity: number; clumpSize: number }[],
      lodHysteresis: 0.12,
      /**
       * GRASS PATCHES: grass does not cover the land evenly. A low-frequency noise (`scale` m, 20..60 looks right) decides where it grows.
       * `coverage` = share of the land that lies inside a patch (the noise threshold is found from the world seed, so it is a real share).
       * Inside a patch the cover is dense: tufts at `density` x the old chance plus clumps (`clumpChance` per clump cell, they overlap).
       * Outside a patch there is bare soil: no tuft at all where the patch value is below `minValue`. The rim is soft: `edge` = softness in noise
       * units (about 4 m at scale 40), and tufts / clumps at the rim are fewer and smaller (`edgeScale` = their size at the very rim, 1 in the
       * core; the core starts at patch value `coreAt`). Road sides and landmark plots are pulled into a patch (`boost` = patch value there,
       * 0 = off): `roadStep` widens the road mask (reach ~ step * 0.6 + shoulder metres), `landmarkReach` m around plots / placed buildings,
       * `gridStep` = resolution (m) of that road / landmark field.
       */
      patch: {
        scale: 40,
        coverage: 0.4, // only 30 % of the land has grass (patches), the rest is bare soil (was 1 = grass everywhere)
        edge: 0.2,
        minValue: 0.25,
        coreAt: 0.35,
        density: 1,
        clumpChance: 0.15, // 2026-11-21: big bunch grass (tussocks, a share with seed plumes) grows in the grass patches again, like the savanna photo (was 0 = only single grass). ~0.15 = one bunch per ~15 m2 of patch; 0 = off
        edgeScale: 0.5,
        boost: 0.9,
        roadStep: 24,
        landmarkReach: 24,
        gridStep: 2,
      },
      /**
       * GRASS CLUMPS: one clump = 60..110 blades in one bunch (a tussock), ~0.8..1.5 m wide and 0.5..1.1 m tall. They grow on their own
       * grid (`cell`, tile / cell must be whole), only inside patches (see `patch.clumpChance`).
       */
      clump: {
        cell: 1.6,
        /** A clump is at most `maxHeight` m high (50 cm); its width = its height scale x `width` (the far rings make it a bit wider). */
        maxHeight: 0.25, // 2026-11-23: 0.25x (was 1.0)
        width: 1.8,
        /** The tall seed-plume bunch (tussockSeed) is this many times taller than the other clumps (its plumes stand above its blades). */
        seedTall: 1.3,
      },
      /**
       * TREE-BASE GRASS: grass does NOT grow scattered over open ground. It grows in a soft ring around every tree trunk and bamboo clump (a tuft bed, like real
       * undergrowth), thick at the trunk and thinning out to nothing at `reach` m (x 0.7..1.3 with the tree size). Open soil between trees stays bare.
       * `chance` = chance per cell inside the ring (cell 0.5 m); city lawn, roads and farm / plot rules are unchanged. enabled false = the old patchy meadow.
       */
      treeBase: { enabled: false /* 2026-11-23: NO grass rings round the tree bases (user): the grass is the patchy meadow only */, reach: 3.0, chance: 1, core: 0.75, meadow: 0.5 /* 2026-11-23: DENSER grass: the meadow patches grow again (x `meadow` of the patch noise) besides the rings round the trees; ring reach 2.6 -> 3.0; ~2x tufts in open land (0 = the old tree rings only) */ }, // SMALLER but MUCH DENSER ring: every cell has grass, full density out to `core` x reach, then a short soft rim (was reach 3.2, chance 0.7, core 0.45)
      /** Chance per cell inside a meadow / on bare patches, and the extra thinning inside forests. Higher = denser, fewer bald patches. */
      maxChance: 0.7, // SPARSE: ~1 cell in 3 grows a tuft (was 0.98 / 0.9 = every cell)
      minChance: 0.28,
      forestThin: 0.3,
      /**
       * JUNGLE FLOOR (ghono jongol ground cover): inside the dense jungle every cell gets grass (`floor` = patch value forced up to this x jungle density, so no bald
       * ground), tufts are `tall` x higher, `chance` = grass chance per cell, and the grass kinds are mixed (wild, tussocks, broad-leaf, seed-head). Flag 6 in the tuft data.
       */
      jungle: { floor: 1.0, tall: 1.0, tallFlower: 0.85, tallClump: 0.7, chance: 0.9, clumpChance: 0.06, clear: 2 }, // 2026-11-21: grass is back in the jungle (clear 2 = never skipped) // 2026-11-20: NO grass in the dense jungle (floor / chance / clumpChance 0); `clear` = jungle density above which no tuft or clump is placed
      /** Blades per tuft model are multiplied by this (1 = full quality; 0.6 for weak GPUs). */
      bladeDensity: 1,
      /** 2026-11-23: false = NO broad-leaf ground cover anywhere (leafy rosettes and clover patches turn into the fine single grass); the models stay for a water lily. */
      broadLeaf: false,
      /** Central station park lawn: its blades are this many times taller than the city lawn. */
      // HK-FIX12: the GRASS of the Central park / Hatikamrul gardens (the FLOWER size is LOCKED in vegetation/GardenFlowerLock.ts, not here). Height in METRES (lo .. hi by a hash), `widthMul` = finer blades (1 = the normal grass width), deepTint x deepVar = deep green colour (multiplies the painted blade cards).
      garden: { grass: [0.7, 0.9], filler: [0.3, 0.45], widthMul: 0.275, deepTint: [0.4, 0.72, 0.45], deepVar: [0.72, 0.3], lean: 0.45 }, // HK-FIX14: lean = total tilt range (rad, +-0.22 = +-13 deg) of a tall garden / jungle-floor tuft; the jungle floor grass uses the same `grass` height and `widthMul`
      /** Wildflowers: share of tufts that carry flowers inside a flower patch / scattered in the open meadow. Patches are ~12-30 m wide. */
      flowerInPatch: 0.05, // was 0.14: far fewer flowers
      flowerScatter: 0.002, // was 0.006
      /** Steepest ground (rise / run) with grass; it thins out from `slopeFadeFrom`. The terrain shader turns to rock at ~0.5. */
      maxSlope: 0.45,
      slopeFadeFrom: 0.28,
      /** Grass thins out above these heights (m); colour goes from green to dry between dryFrom and dryTo (like the terrain shader). */
      heightFadeStart: 200,
      heightFadeEnd: 300,
      dryFrom: 120,
      dryTo: 280,
      /**
       * GREEN CITY LAWN: everywhere inside a planned city area that is not road, pavement, plaza, parking or a building plot (the same `blocked` list as
       * everywhere else) the ground is lawn. No patches there (patch value forced to 1 inside the city, soft edge `edge` m outside it), the 0.5 city thinning
       * of the old `cityChance` is gone. Flag in the data (last float): 2 = lawn tuft, 3 = tall clump at a tree base / fence.
       *   density      tuft chance multiplier of lawn cells (1 = the old open-meadow density; 0.55 keeps the instance count sane)
       *   height       lawn tufts are this fraction of the normal height (short, mown)
       *   clumpChance  small clumps scattered over the lawn (per clump cell), clumpScale their size
       *   baseChance   clumps at tree bases and along plot fences (per clump cell inside the band), baseScale their size (taller), baseReach / fenceReach metres
       *   flowerShare  share of lawn tufts that carry a small flower (daisy, clover, buttercup)
       *   edge         metres over which the lawn blends into the normal patchy meadow outside the city
       */
      city: { density: 1, height: 1.5, dense: 1.8, clumpChance: 0, clumpScale: 0.8, baseChance: 0, baseScale: 1.3, baseReach: 1.6, fenceReach: 1.4, flowerShare: 0.02, edge: 40 },
      /**
       * HIGHWAY VERGE outside cities: beyond the gravel shoulder the road side is a grass patch (patch value forced up, like the road-side boost) with
       * tall clumps; `reach` = width (m) of the strip next to the shoulder, `clumpChance` per clump cell inside it, `tall` = clump height multiplier.
       */
      verge: { reach: 7, clumpChance: 0, tall: 1.35, density: 1 },
      /**
       * COLOUR: every tuft is fresh green, yellow-green or straw (`strawShare` of the tufts lean to straw outside the city, `yellowShare` to yellow-green).
       * `rootDark` = brightness of the blade at the root (0..1, 1 = no darkening), `wind` = global wind sway multiplier (0 = still air; the sway grows with blade height, so short lawn moves little anyway).
       */
      look: { smoothBlades: true, bladeWidth: 1.1, strawShare: 0, yellowShare: 0, rootDark: 0.6, wind: 0, bladeVariation: 1 }, // bladeWidth was 0.28, now x3 wider
      /**
       * SINGLE GRASS: every tuft model has only `blades[0]..blades[1]` blades (3-5 leaves per grass), so the ground can be covered with very many
       * of them cheaply (`cell` 0.2 m). Used for the four grass kinds; flowers keep their own base. enabled false = the old many-blade tufts.
       */
      /** false = NO white things in the grass: no daisy, no clover (white pom-pom), no pale seed-head grass (they become plain green grass). Coloured flowers stay. */
      whiteFlowers: false,
      /**
       * GROUND-COVER LEAVES (2026-11-21, `leafy` rosettes of broad leaves and `trefoil` clover patches, mixed into the tufts of the tree-base ring, the road verge, the lawn and the jungle floor):
       * their height in metres (the tallest point of the model); the width follows the model (a rosette is ~1.3x wider than high). `bladeVariation` (look): 1 = each blade its own tone, 0 = all alike.
       */
      leafy: { maxHeight: 0.16, trefoilHeight: 0.14 },
      single: { enabled: true, blades: [6, 9] as [number, number] }, // fuller tufts (was 3-5 thin blades)
      /** No grass is made while the camera is higher than this above the ground (m): free-fly / helicopter. */
      maxAboveGround: 25,
      /** While the camera moves faster than this (m/s, ~43 km/h) NO new grass tile is asked from the workers (car / plane / free-fly): existing tiles just fall out of range. */
      maxSpeed: 12,
    },
  },

  /** STAGE 9: people on foot. */
  people: {
    /** How many people on foot the world keeps around the player. */
    target: 34,
    spawnEvery: 0.35,
    /** Ring around the player (m) where new people appear / beyond which they are removed. */
    spawnMin: 40,
    spawnMax: 190,
    despawnRadius: 240,
    /** Share of the people who wander in the open (the rest walk along road edges) while the player is in a city zone. */
    wanderShare: 0.4,
    run: 5.2,
  },

  /** Weapons, wanted level and damage balance; player health remains protected. */
  combat: {
    weapons: {
      // Game-balance values for stylised fictional weapons; these are not real-world ballistics.
      pistol:          { interval: 0.30, auto: false, damage: 34, pellets: 1, spread: 0.012, range: 180, gunLength: 0.20, magazine: 12, reserve: 60, reserveMax: 120, reload: 1.4 },
      combatPistol:    { interval: 0.24, auto: false, damage: 39, pellets: 1, spread: 0.010, range: 210, gunLength: 0.22, magazine: 15, reserve: 75, reserveMax: 150, reload: 1.5 },
      heavyPistol:     { interval: 0.38, auto: false, damage: 52, pellets: 1, spread: 0.014, range: 230, gunLength: 0.23, magazine: 8, reserve: 48, reserveMax: 96, reload: 1.8 },
      revolver:        { interval: 0.52, auto: false, damage: 68, pellets: 1, spread: 0.009, range: 260, gunLength: 0.22, magazine: 6, reserve: 36, reserveMax: 72, reload: 2.0 },
      microSmg:        { interval: 0.075, auto: true, damage: 13, pellets: 1, spread: 0.042, range: 125, gunLength: 0.28, magazine: 24, reserve: 144, reserveMax: 288, reload: 1.7 },
      smg:             { interval: 0.085, auto: true, damage: 17, pellets: 1, spread: 0.030, range: 160, gunLength: 0.34, magazine: 30, reserve: 150, reserveMax: 300, reload: 1.9 },
      ak47:            { interval: 0.105, auto: true, damage: 24, pellets: 1, spread: 0.023, range: 270, gunLength: 0.47, magazine: 30, reserve: 180, reserveMax: 360, reload: 2.1 },
      carbineRifle:    { interval: 0.095, auto: true, damage: 22, pellets: 1, spread: 0.018, range: 320, gunLength: 0.46, magazine: 30, reserve: 180, reserveMax: 360, reload: 2.0 },
      shotgun:         { interval: 0.85, auto: false, damage: 14, pellets: 8, spread: 0.065, range: 60, gunLength: 0.50, magazine: 6, reserve: 30, reserveMax: 60, reload: 2.4 },
      sniperRifle:     { interval: 1.15, auto: false, damage: 95, pellets: 1, spread: 0.0035, range: 650, gunLength: 0.62, magazine: 5, reserve: 25, reserveMax: 50, reload: 2.8 },
    },
    /** Q cycles the full fictional GTA-inspired catalogue. */
    order: ['pistol', 'combatPistol', 'heavyPistol', 'revolver', 'microSmg', 'smg', 'ak47', 'carbineRifle', 'shotgun', 'sniperRifle'] as const,
    /** A killed armed person drops this many magazines of his gun (added to the player's reserve ammo). */
    lootMagazines: 1,
    personHealth: 100,
    headshotMultiplier: 3,
    /** Hit cylinder of a person (radius in m; the head starts at this share of the body height). */
    bodyRadius: 0.38,
    headFrom: 0.84,
    /** The gun stays in the hand this long (s) after the last shot / aim. */
    drawSeconds: 4,
    /** While aiming (right mouse button) the camera moves this much closer. */
    aimCameraScale: 0.6,
    /** Aiming makes bullets this much more accurate. */
    aimAccuracy: 0.5,
    /** Bodies stay on the ground this long (s). */
    deadLinger: 25,
    /** Share of the walking people who carry a gun and want to kill the player. */
    thugShare: 0.035,
    /** Armed people see (and start shooting at) the player within this distance (m). */
    sightRange: 38,
    /** They fire only up to this distance (m) and keep this distance (m) while shooting. */
    fireRange: 52,
    keepDistance: 16,
    /** Hit chance of an NPC shot = max(minHit, baseHit - distance * hitFalloff). */
    baseHit: 0.38,
    minHit: 0.05,
    hitFalloff: 0.011,
    /** Damage the player takes per NPC hit - only used for the red screen flash (the player is immortal). */
    npcDamage: 12,
    /** People within this distance (m) of a shot / killing run away (or fight, when armed). */
    alarmRadius: 25,
    fleeSeconds: 10,
    /** Wanted level (time based): crime weight, seconds of crime that keep the window open / each crime adds per weight, fade per second, crime seconds needed for star 1..5, police per star. */
    wanted: { killCivilian: 1, woundCivilian: 0.4, killPolice: 2, shootPolice: 0.6, activeWindow: 20, bonusPerHeat: 0, decay: 2, starAt: [120, 300, 420, 510, 600], policePerStar: 1, spawnMin: 65, spawnMax: 105, spawnEvery: 3.8, leaveAfter: 22 },
  },

  /** STAGE 9: AI traffic. Every vehicle has a driver (a person); there are no empty cars. */
  traffic: {
    target: 40,
    /** TRAFFIC 2x (user 2026-11-23: 'full game a traffic 2x'): the AI car target (also the quality presets' trafficTarget) and the bus limit are multiplied by this. 1 = the old traffic, 2 = double. */
    densityMul: 2,
    spawnEvery: 0.2,
    spawnMin: 110,
    spawnMax: 260,
    /** Cars farther than this from the player are removed (the physics only runs near the player anyway). */
    despawnRadius: 285,
    /** Minimum free distance (m) to other vehicles when a new car appears. */
    spawnGap: 25,
    /** What kind of vehicle appears, where, and how often: see `use` of each spec in vehicles/VehicleSpec.ts (vehicles/VehicleUse.ts). */
    /** At most this many buses at the same time. */
    maxBuses: 3,
    /**
     * BIG HIGHWAYS (6 lanes = 3 per direction): AI traffic drives much faster here than the road's normal speed limit.
     * Cars use the middle / fast lane and cruise up to `limitKmh` (each driver at 70..98 % of it); cargo trucks and fuel tankers (highway-only vehicles)
     * keep to the kerb lane at their own much lower speed, `truckKmh` / `tankerKmh`.
     */
    highway: { minLanes: 6, limitKmh: 130, truckKmh: 75, tankerKmh: 80, sportKmh: 175 },
    /**
     * AI ENERGY (step 2): AI cars use fuel / battery like the player's (vehicles/Energy.ts). A car appears with `startMin`..1 of a tank; at `lowAt` it looks for a free fuel
     * station (fuel cars) or charge point (electric cars: rickshaw, bus, evhypar) on its highway, ahead of it, and stands there until it is full again (`fuelSeconds` /
     * `chargeSeconds` for an empty -> full refill, at least 3 s). `floor`: an AI car never runs completely dry (it would block the road): it limps on at this level.
     * A car that appears with a station within `nearStationM` ahead is low on energy (`lowStartMin`..`lowStartMax`) with the chance `lowShare`, so visits happen where the player can see them.
     */
    energy: { startMin: 0.35, lowAt: 0.28, floor: 0.06, lowStartMin: 0.12, lowStartMax: 0.26, lowShare: 0.4, nearStationM: 900, fuelSeconds: 9, chargeSeconds: 14 },
  },

  lod: {
    /**
     * Distance (m, measured to the nearest edge of the chunk) up to which each LOD is used.
     * LOD0 = most detailed ... LOD3 = coarsest. The last value is also the load radius.
     * Near the camera everything is detailed; far away only a coarse, cheap terrain (no trees, no road ribbons) is drawn.
     */
    distances: [380, 900, 1900, 3600] as number[],
    /** Vertices per chunk side for each LOD. */
    vertsPerSide: [128, 64, 32, 16] as number[],
    /** 8 % hysteresis so chunks do not flicker between LODs at the border. */
    hysteresis: 0.08,
  },

  chunk: {
    /** Re-evaluate wanted chunks when the player moved this far (m). */
    reevaluateDistance: 32,
    /** Max chunk requests being generated by workers at the same time. */
    maxInFlight: 10,
    /** Max chunk meshes added to the scene per frame (avoids hitches). */
    maxMeshesPerFrame: 2,
    /** New chunks fade in (dithered) over this many seconds. */
    fadeSeconds: 0.7,
  },

  loop: {
    fixedStep: 1 / 60,
    maxSubSteps: 5,
    /** Frames longer than this are clamped (tab was in background etc.). */
    maxFrameTime: 0.25,
  },

  floatingOrigin: {
    /** When the camera is farther than this from the scene origin (x or z), the origin is re-centred. */
    threshold: 2000,
  },

  environment: {
    /** Fog density (FogExp2). 0.00046 -> ~95 % fogged at the 3.6 km load radius, hides chunk pop-in and the far, coarse terrain. */
    fogDensity: 0.00046,
    shadowExtent: 350,
    shadowMapSize: 4096,
    /** Day / night cycle (see src/environment/DayNight.ts). Night can be switched off in the game with the \ key. */
    dayNight: {
      /** Minutes from sunrise to sunset. */
      dayMinutes: 8,
      /** Minutes from sunset to sunrise (the dusk and dawn colour changes happen inside these times, never as a sudden jump). */
      nightMinutes: 3,
      /** The game starts at this fraction of the day (0 = sunrise, 1 = sunset): mid-morning. */
      startFraction: 0.21,
      /** Seconds the sky needs to fade to full day when the night mode is switched off (and back when it is switched on). */
      switchSeconds: 6,
    },
  },

  player: {
    height: 1.8,
    radius: 0.35,
    /** Metres per second. */
    walk: 4.2,
    run: 8.5,
    swim: 2.6,
    swimSprint: 4.4,
    jump: 5.2,
    /** Feet depth under water (m) to start / stop swimming (hysteresis). */
    swimEnter: 1.25,
    swimExit: 0.75,
    /** Breath under water (seconds), how fast it refills at the surface (per second), seconds at zero before blacking out. */
    oxygenSeconds: 45,
    oxygenRefill: 0.7,
    drownGrace: 5,
    /** Dive speed (m/s) and with Shift. */
    diveSpeed: 2.2,
    diveSprint: 3.4,
    maxSlopeDeg: 55,
    stepHeight: 0.5,
    /** TREE CLIMBING: walk into a trunk and press Space. Up / down speed (m/s), sideways speed round the trunk (m/s), how close (m, from the trunk surface to the body centre) a trunk must be to grab it. */
    climb: { up: 1.7, down: 2.4, around: 1.3, reach: 0.8 },
    /** Invisible wall: the player cannot leave the playable area. */
    bound: 5000,
  },

  orbit: {
    startYaw: Math.PI, // looking south (towards the sea)
    startElevation: 0.35,
    distance: 6,
    minDistance: 2.5,
    maxDistance: 25,
    minElevation: -0.25,
    maxElevation: 1.45,
    /** Camera looks at a point this far above the capsule centre (shoulder/head height). */
    targetHeight: 0.55,
    /** On foot the camera sits this far to the RIGHT of the player (m): the crosshair in the screen centre does not sit on his back. */
    shoulder: 0.9,
  },

  /** FIRST PERSON (P on foot): the camera sits at the player's real eyes. */
  firstPerson: {
    /** Eye height above the feet (m) standing, how much it drops while crouching (C), and how far it sits in front of the capsule axis. */
    eyeHeight: 1.62,
    crouchDrop: 0.5,
    eyeForward: 0.06,
    /** Near plane (m): the body is hidden, so the eye may look at things right in front of the nose (the capsule keeps walls >= 0.29 m away). */
    near: 0.22,
    /** The eye is never closer than this to the terrain surface (m). */
    groundClearance: 0.3,
    /** Aiming (right mouse): how much of the field of view is cut at full aim (0.4 = 40 %). */
    aimZoom: 0.4,
  },

  camera: {
    fov: 70,
    near: 1,
    far: 16_000,
    startPosition: { x: 0, y: 140, z: 0 },
    startPitch: -0.3,
    mouseSensitivity: 0.0022,
    baseSpeed: 80,
    minSpeed: 2,
    maxSpeed: 3000,
    boostMultiplier: 8,
    /** Free-fly camera never goes closer than this to the ground (m). */
    groundClearance: 2,
  },
};
