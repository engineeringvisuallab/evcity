// EVLab parking lot (Step 7): the meshes. Layout numbers are in EVLabParking (pure). Building-local metres.
// Flat asphalt, one merged mesh of white bay lines, low kerbs, the entry road to the N arm of J1 and a few lamp posts.
// No colliders (like the other parking lots: the ground is the ground; the kerb is only 14 cm high).
import * as THREE from 'three';
import { DRIVE, DRIVE_PTS, LAMPS, LOT, kerbRects, paintRects } from './EVLabParking';
import { roadStrip } from './EVLabRoads';
import type { Parts } from './EVLabParts';

export interface ParkingLotBuild {
  group: THREE.Group;
  /** Lamp post positions (building-local x, z): EVLabGrounds adds them to its instanced lamps. */
  lamps: Array<[number, number]>;
}

/** One geometry from many flat rectangles [x0, x1, z0, z1] at height y (all faces up). */
function flatRects(P: Parts, rects: ReadonlyArray<readonly [number, number, number, number]>, y: number): THREE.BufferGeometry {
  const pos: number[] = [], nor: number[] = [], idx: number[] = [];
  for (const [x0, x1, z0, z1] of rects) {
    const b = pos.length / 3;
    pos.push(x0, y, z0, x0, y, z1, x1, y, z0, x1, y, z1);
    nor.push(0, 1, 0, 0, 1, 0, 0, 1, 0, 0, 1, 0);
    idx.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
  }
  const geo = P.k.own(new THREE.BufferGeometry());
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  geo.setIndex(idx);
  return geo;
}

/**
 * `ground(x, z)` (optional) = height of the real ground above the floor level (m) at a building-local point. The entry road follows it, because the last
 * metres before the F6 highway run down to the highway's own level (0.5 m lower than the campus floor). Without it the road is flat.
 */
export function buildParkingLot(P: Parts, road: THREE.Material, ground?: (x: number, z: number) => number): ParkingLotBuild {
  const { k } = P;
  const g = new THREE.Group();
  g.name = 'EVLabParkingLot';
  const y = 0.05; // same height as the campus roads (just above the levelled terrain)

  const mat = (color: number, factor: number): THREE.MeshLambertMaterial =>
    k.own(new THREE.MeshLambertMaterial({ color, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: factor, polygonOffsetUnits: factor }));

  // asphalt of the lot (the same grey as the roads), then the white paint on top of it
  const asphalt = new THREE.Mesh(flatRects(P, [[LOT.x0, LOT.x1, LOT.z0, LOT.z1]], y), mat(0x5f6366, -2));
  asphalt.receiveShadow = true;
  const paint = new THREE.Mesh(flatRects(P, paintRects(), y + 0.012), mat(0xf1f1ea, -4));
  paint.receiveShadow = true;
  g.add(asphalt, paint);

  // low concrete kerb round the lot (open at the entry road and at the promenade walkway)
  const kerbMat = P.lit(null, 0x9a9ea3, 0.05);
  for (const [x0, x1, z0, z1] of kerbRects()) P.tbox(g, x0, x1, z0, z1, 0, y + 0.14, kerbMat);

  // the entry road: from the middle of the cross aisle south, then east to the N arm of J1 (asphalt ribbon; it follows the ground, which is flat under the strip and
  // the gate road and slopes only a little beyond the pad). It stops at the arm's pavement edge; the junction itself is Step R6.
  const pts: Array<[number, number]> = DRIVE_PTS.map(([x, z]) => [x, z]);
  // (flat ground is 0.03 m below the floor: + 0.08 = the same 0.05 as the lot)
  const ys = pts.map(([x, z]) => (ground ? ground(x, z) + 0.08 : y));
  roadStrip(g, k, pts, DRIVE.halfW, y, road, 8, ys);

  return { group: g, lamps: LAMPS.map(([x, z]) => [x, z] as [number, number]) };
}
