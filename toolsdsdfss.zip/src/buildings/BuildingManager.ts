// PROTOTYPE building inside the open world: the police station (thana) from src/buildings/models.
//  - the model (one merged mesh per surface) stands at PROTO_POS on a flat pad (terrain.protoBuilding), always there when the game starts
//  - Rapier colliders from the model's own solid parts (walls with door openings, roof slabs, wings, boundary wall, vehicles, trees ...): the station is walk-in
//  - a paved apron over the whole plot and a footpath from the gate to the F6 road
//  - hidden when the player is far away
// To use another model: change PROTO_MODEL_ID in ProtoSite.ts (and the colliders below).
import * as THREE from 'three';
import type RAPIER from '@dimforge/rapier3d-compat';
import type { PhysicsWorld } from '../physics/PhysicsWorld';
import type { FloatingOrigin } from '../world/FloatingOrigin';
import type { TerrainGenerator } from '../terrain/TerrainGenerator';
import { BUILDING_MODEL_BY_ID } from './models/registry';
import type { BuiltBuilding } from './models/BuildingKit';
import { PROTO_HALF, PROTO_MODEL_ID, PROTO_PATH, PROTO_SIZE } from './ProtoSite';

export interface BuildingDeps {
  root: THREE.Object3D; // world.root: children use ABSOLUTE world coordinates
  physics: PhysicsWorld;
  origin: FloatingOrigin;
  terrain: TerrainGenerator;
  /** World position of the player (the capsule centre). */
  playerWorld: (out: THREE.Vector3) => THREE.Vector3;
}

const SHOW_DIST = 2000; // the building is drawn within this distance (was 900)
const FLOOR_TOP = 0.1; // the compound's own paving is 6-10 cm above the pad

export class BuildingManager {
  readonly building: BuiltBuilding;
  readonly group: THREE.Group;
  /** True while the player stands anywhere on the plot (HUD label). */
  inside = false;
  private body: RAPIER.RigidBody;
  private apron: THREE.Mesh;
  private path: THREE.Mesh;
  private p = new THREE.Vector3();

  constructor(private d: BuildingDeps) {
    const site = d.terrain.protoBuilding;
    const def = BUILDING_MODEL_BY_ID[PROTO_MODEL_ID];
    if (!def) throw new Error(`building model "${PROTO_MODEL_ID}" not found`);
    this.building = def.build(0);
    this.group = this.building.root;
    this.group.position.set(site.x, site.floorY, site.z);
    this.group.rotation.y = site.yaw;
    d.root.add(this.group);

    // paved apron: the whole level plot (the compound stands on it), then the footpath to the road. Both are turned with the building (yaw), laid flat.
    const mat = (color: number) =>
      new THREE.MeshStandardMaterial({ color, roughness: 0.95, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    this.apron = new THREE.Mesh(new THREE.PlaneGeometry(PROTO_HALF.x * 2, PROTO_HALF.z * 2), mat(0xb9b5ab));
    this.apron.rotation.order = 'YXZ';
    this.apron.rotation.set(-Math.PI / 2, site.yaw, 0);
    this.apron.position.set(site.x, site.floorY - 0.015, site.z);
    d.root.add(this.apron);
    const plen = PROTO_PATH.len;
    const pmid = PROTO_HALF.z - 1 + plen / 2; // local +z of the path centre
    this.path = new THREE.Mesh(new THREE.PlaneGeometry(PROTO_PATH.halfWidth * 2, plen), mat(0xa8a49a));
    this.path.rotation.order = 'YXZ';
    this.path.rotation.set(-Math.PI / 2, site.yaw, 0);
    this.path.position.set(site.x + pmid * Math.sin(site.yaw), site.floorY - 0.01, site.z + pmid * Math.cos(site.yaw));
    d.root.add(this.path);

    this.body = this.createColliders();
  }

  /** Fixed Rapier body in floating-origin local coordinates (PhysicsWorld shifts it when the origin moves). */
  private createColliders(): RAPIER.RigidBody {
    const R = this.d.physics.RAPIER;
    const world = this.d.physics.world;
    const site = this.d.terrain.protoBuilding;
    const o = this.d.origin.origin;
    const body = world.createRigidBody(
      R.RigidBodyDesc.fixed()
        .setTranslation(site.x - o.x, site.floorY, site.z - o.z)
        .setRotation({ x: 0, y: Math.sin(site.yaw / 2), z: 0, w: Math.cos(site.yaw / 2) }),
    );
    /** Box by local min/max x, z and y range. */
    const box = (x0: number, x1: number, z0: number, z1: number, y0: number, y1: number, friction = 0.4, rot = 0): void => {
      world.createCollider(
        R.ColliderDesc.cuboid((x1 - x0) / 2, (y1 - y0) / 2, (z1 - z0) / 2)
          .setTranslation((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2)
          .setRotation({ x: 0, y: Math.sin(rot / 2), z: 0, w: Math.cos(rot / 2) })
          .setFriction(friction),
        body,
      );
    };
    const hx = PROTO_SIZE.W / 2, hz = PROTO_SIZE.D / 2;
    // floor slab (top = the compound's paving): walking is perfectly smooth
    box(-hx, hx, -hz, hz, -1, FLOOR_TOP, 1);
    // the model's own solid parts: walls with the door openings, roof slabs, wings, parked vehicles, boundary wall (gate open), trees ...
    const info = this.building.info;
    for (const s of info.solids) {
      world.createCollider(
        R.ColliderDesc.cuboid(s.hx, s.hy, s.hz).setTranslation(s.x, s.y, s.z).setRotation({ x: 0, y: Math.sin(s.yaw / 2), z: 0, w: Math.cos(s.yaw / 2) }).setFriction(0.4),
        body,
      );
    }
    for (const c of info.cyls) world.createCollider(R.ColliderDesc.cylinder(c.hh, c.r).setTranslation(c.x, c.y, c.z), body);
    return body;
  }

  /** Minimap marker position. */
  get position(): { x: number; z: number } {
    const s = this.d.terrain.protoBuilding;
    return { x: s.x, z: s.z };
  }

  /** Once per rendered frame. */
  update(): void {
    const site = this.d.terrain.protoBuilding;
    this.d.playerWorld(this.p);
    const dist = Math.hypot(this.p.x - site.x, this.p.z - site.z);
    this.group.visible = this.apron.visible = this.path.visible = dist < SHOW_DIST;
    this.inside = site.onPlot(this.p.x, this.p.z) && this.p.y > site.floorY - 3 && this.p.y < site.floorY + 40;
  }

  dispose(): void {
    this.d.physics.world.removeRigidBody(this.body);
    this.d.root.remove(this.group, this.apron, this.path);
    for (const m of [this.apron, this.path]) {
      m.geometry.dispose();
      (m.material as THREE.Material).dispose();
    }
    this.building.dispose();
  }
}
